#include <device/device.h>


struct chip_operations cpu_intel_socket_mPGA479M_ops = {
	CHIP_NAME("Socket mPGA479M CPU")
};
