unsigned microcode_updates_6ex[] = {
	#include "microcode-1624-m206e839.h"
	#include "microcode-1729-m206ec54.h"
	#include "microcode-1869-m806ec59.h"
};
