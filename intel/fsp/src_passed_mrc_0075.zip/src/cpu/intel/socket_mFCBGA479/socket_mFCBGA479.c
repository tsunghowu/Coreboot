#include <device/device.h>

struct chip_operations cpu_intel_socket_mFCBGA479_ops = {
	CHIP_NAME("Micro-FCBGA 479 CPU")
};
