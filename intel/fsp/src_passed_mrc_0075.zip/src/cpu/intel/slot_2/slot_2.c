#include <device/device.h>


struct chip_operations cpu_intel_slot_2_ops = {
	CHIP_NAME("Slot 2 CPU")
};
