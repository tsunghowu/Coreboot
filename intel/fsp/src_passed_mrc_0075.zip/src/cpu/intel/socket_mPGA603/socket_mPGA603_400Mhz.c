#include <device/device.h>


struct chip_operations cpu_intel_socket_mPGA603_ops = {
	CHIP_NAME("Socket mPGA603 400Mhz CPU")
};
