#include <device/device.h>

struct chip_operations cpu_intel_socket_rPGA988B_ops = {
	CHIP_NAME("Socket rPGA988B CPU")
};
