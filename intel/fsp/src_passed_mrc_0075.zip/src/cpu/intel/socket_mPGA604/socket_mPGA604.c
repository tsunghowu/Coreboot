#include <device/device.h>


struct chip_operations cpu_intel_socket_mPGA604_ops = {
	CHIP_NAME("Socket mPGA604 CPU")
};
