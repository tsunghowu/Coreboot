unsigned microcode_updates_69x[] = {
	#include "microcode-1376-m8069547.h"
	#include "microcode-1373-m1069507.h"
	#include "microcode-1374-m2069507.h"
};
