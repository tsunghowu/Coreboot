#include <device/device.h>

struct chip_operations cpu_intel_socket_BGA956_ops = {
	CHIP_NAME("Socket BGA956 CPU")
};
