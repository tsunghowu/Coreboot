#include <device/device.h>

struct chip_operations cpu_intel_socket_PGA370_ops = {
	CHIP_NAME("Socket PGA370 CPU")
};
