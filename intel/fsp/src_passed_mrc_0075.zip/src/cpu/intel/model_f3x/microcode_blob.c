unsigned microcode_updates_f3x[] = {
#include "microcode-1290-m0df320a.h"
#include "microcode-1467-m0df330c.h"
#include "microcode-1468-m1df3417.h"
};
