#include <device/device.h>

struct chip_operations cpu_intel_socket_rPGA989_ops = {
	CHIP_NAME("Socket rPGA989 CPU")
};
