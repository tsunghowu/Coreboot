unsigned microcode_updates_6dx[] = {
	#include "microcode-1355-m206d618.h"
};
