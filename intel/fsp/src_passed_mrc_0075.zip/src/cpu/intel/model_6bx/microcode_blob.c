unsigned microcode_updates_6bx[] = {
	#include "microcode-737-MU16b11c.h"
	#include "microcode-738-MU16b11d.h"
	#include "microcode-875-MU16b401.h"
	#include "microcode-885-MU16b402.h"
};
