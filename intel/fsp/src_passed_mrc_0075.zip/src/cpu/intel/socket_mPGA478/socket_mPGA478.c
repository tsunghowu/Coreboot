#include <device/device.h>


struct chip_operations cpu_intel_socket_mPGA478_ops = {
	CHIP_NAME("Socket mPGA478 CPU")
};
