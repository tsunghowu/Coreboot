/* 256KB cache */
unsigned microcode_updates_f1x[] = {
	#include "microcode-1068-m01f122d.h"
	#include "microcode-1069-m04f122e.h"
	#include "microcode-1070-m02f122f.h"
	#include "microcode-1072-m04f1305.h"
};
