#include <device/device.h>


struct chip_operations cpu_intel_socket_LGA771_ops = {
	CHIP_NAME("Socket LGA771 CPU")
};
