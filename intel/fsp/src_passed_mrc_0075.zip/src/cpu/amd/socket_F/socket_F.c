#include <device/device.h>

struct chip_operations cpu_amd_socket_F_ops = {
	CHIP_NAME("Socket F CPU")
};
