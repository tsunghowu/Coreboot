#include <device/device.h>

struct chip_operations cpu_amd_socket_S1G1_ops = {
	CHIP_NAME("Socket S1G1 CPU")
};
