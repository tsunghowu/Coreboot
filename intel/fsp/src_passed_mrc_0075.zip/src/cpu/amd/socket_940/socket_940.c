#include <device/device.h>

struct chip_operations cpu_amd_socket_940_ops = {
	CHIP_NAME("Socket 940 CPU")
};
