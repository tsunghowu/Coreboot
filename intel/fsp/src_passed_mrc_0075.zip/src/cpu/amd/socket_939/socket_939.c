#include <device/device.h>

struct chip_operations cpu_amd_socket_939_ops = {
	CHIP_NAME("Socket 939 CPU")
};
