#include <device/device.h>

struct chip_operations cpu_amd_socket_AM2_ops = {
	CHIP_NAME("Socket AM2 CPU")
};
