#include <device/device.h>


struct chip_operations cpu_amd_socket_754_ops = {
	CHIP_NAME("Socket 754 CPU")
};
