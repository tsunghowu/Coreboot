/*
 * Placeholder for code to come (needed to complete build)
 *
 * Copyright (C) 2013  Alexandru Gagniuc <mr.nuke.me@gmail.com>
 * Subject to the GNU GPL v2, or (at your option) any later version.
 */

#include <timer.h>

void timer_monotonic_get(struct mono_time *mt)
{
	(void)mt;
}
