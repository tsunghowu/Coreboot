/*
 * Allwinnwer A10 devicetree config struct
 *
 * Copyright (C) 2013  Alexandru Gagniuc <mr.nuke.me@gmail.com>
 * Subject to the GNU GPL v2, or (at your option) any later version.
 */

#include <types.h>

struct cpu_allwinner_a10_config {
};
