#include <arch/io.h>
#include <console/console.h>
#include <console/streams.h>
#include <console/vtxprintf.h>
#include <smp/spinlock.h>
#include <smp/node.h>
#include <stddef.h>
#include <trace.h>

//;********************************************************************************
//<DEBUG>
/*
    MmioOr16 ((UINTN) (RootComplexBar + R_PCH_SPI_HSFS), (UINT16) (B_PCH_SPI_HSFS_FLOCKDN));
    SCRIPT_MEM_WRITE (
      EFI_ACPI_S3_RESUME_SCRIPT_TABLE,
      EfiBootScriptWidthUint16,
      (UINTN) (RootComplexBar + R_PCH_SPI_HSFS),
      1,
      (VOID *) (UINTN) (RootComplexBar + R_PCH_SPI_HSFS)
      );
*/
//<DEBUG>
//;*********************************************************************************/


#define SPI_BASE_ADDRESS	0x3800
#define SB_RCBA	0xfed1c000

#if SPI_BASE_ADDRESS > SB_RCBA
#define	SPI_ACCESS_BASE	SPI_BASE_ADDRESS
#else
#define	SPI_ACCESS_BASE	SB_RCBA+SPI_BASE_ADDRESS
#endif
 
#define   SC_INTEL_REG_SPI_FADDR		0x08      	// Flash Address
#define   SC_INTEL_REG_SPI_FDATA0		0x10      	// Flash Data 0

#define   SC_INTEL_REG_SPI_SSFSTS		0x90     	// Software Sequencing Flash Status
#define   SC_INTEL_REG_SPI_SSFSTS_SCDS		0x0004	  	// SSFS[2] : Cycle Done Status
#define   SC_INTEL_REG_SPI_SSFSTS_FCERR		0x0008    	// SSFS[3] : Flash Cycle Error (FCERR) 

#define   SC_INTEL_REG_SPI_SSFCTL		0x91      	// Software Sequencing Flash Control Register
#define   SC_INTEL_REG_SPI_PREOP		0x94      	// Prefix Opcode Configuration
#define   SC_INTEL_REG_SPI_OPTYPE		0x96      	// Opcode Type Configuration
#define   SC_INTEL_REG_SPI_OPMENU		0x98      	// Opcode Menu Configuration


#define	ICH_LPC_PCI_CFG_ADDRESS		 0x80000000|(0<<16)|(0x1F<<11)|(0<<8)  //LPC Interface Bridge Registers (Bus 00, Dev 1f, Fun 00)
#define ICH_REG_LPC_BIOS_CNTL   	 0xDC

#ifndef BIT0
#define 	BIT0                0x01
#endif
#ifndef BIT1
#define 	BIT1                0x02
#endif
#ifndef BIT2
#define 	BIT2                0x04
#endif
#ifndef BIT3
#define 	BIT3                0x08
#endif
#ifndef BIT4
#define 	BIT4                0x10
#endif
#ifndef BIT5
#define 	BIT5                0x20
#endif
#ifndef BIT6
#define 	BIT6                0x40
#endif
#ifndef BIT7
#define 	BIT7                0x80
#endif
#ifndef BIT00
#define 	BIT00	0x00000001
#endif
#ifndef BIT01
#define 	BIT01	0x00000002
#endif
#ifndef BIT02
#define 	BIT02	0x00000004
#endif
#ifndef BIT03
#define 	BIT03	0x00000008
#endif
#ifndef BIT04
#define 	BIT04	0x00000010
#endif
#ifndef BIT05
#define 	BIT05	0x00000020
#endif
#ifndef BIT06
#define 	BIT06	0x00000040
#endif
#ifndef BIT07
#define 	BIT07	0x00000080
#endif

#ifndef VOID
	typedef void VOID;
#endif
#ifndef	UINT8
	#define UINT8 unsigned char
#endif
#ifndef UINT16
	#define UINT16 unsigned short
#endif
#ifndef UINT32
	#define UINT32 unsigned long
#endif 
#ifndef UINT64
	#define UINT64 unsigned long long
#endif 
#ifndef UINTN
	#define UINTN unsigned long
#endif
#ifndef CHAR8
	#define CHAR8 unsigned char
#endif
#ifndef EFI_GUID
	#define EFI_GUID unsigned long
#endif


#define EFI_STATUS  UINTN
#define EFI_SUCCESS 0x00000000
#define EFI_DEVICE_ERROR 0x80000001

EFI_STATUS WaitForCycleDone(VOID);
EFI_STATUS Intel_Spi_No_addr_Wr (
		UINT16	Data_Byte_Count,
		UINT8	Byte1,
		UINT8	Byte2,
		UINT8	Byte3,
		UINT8	Byte4
);
EFI_STATUS Intel_Spi_addr_Rd(
		UINT16	Data_Byte_Count,
		UINT8	Byte1,
		UINT8	Byte2,
		UINT8	Byte3,
		UINT8	Byte4,
	 	UINT32 	*Flash_Data0 
);
EFI_STATUS Intel_Spi_addr_Wr(
		UINT16	Data_Byte_Count,
		UINT8	Byte1,
		UINT8	Byte2,
		UINT8	Byte3,
		UINT8	Byte4,      //Data 0 
    	 	UINT8 	*Flash_Data 
);
EFI_STATUS EM100_Transfer(UINT8 *Data);
EFI_STATUS Intel_Spi_Backup(
    	 	UINT32 	*OpMenuBackup,
    	 	UINT32 	*OpTypeBackup,
			UINT32	*ControlBackup,
    	 	UINT32 	*dAddressBackup,
    	 	UINT8 	*DataBackup
);
EFI_STATUS Intel_Spi_Restore(
    	 	UINT32 	OpMenuBackup,
    	 	UINT32 	OpTypeBackup,
			UINT32	ControlBackup,
    	 	UINT32 	dAddressBackup,
    	 	UINT8 	*DataBackup
);
VOID InitSerialOut(VOID);
VOID SendBytePort (UINT8 Data);
VOID SendStringPort (CHAR8* pstr);
VOID ItoA (UINT32 Value, UINT32 Radix, CHAR8* pstr);
VOID SendByteToBufferPort (UINT8 Data, CHAR8* buffer, UINT16* index);
VOID SendStringToBufferPort (CHAR8* pstr, UINT16 nLength, CHAR8* buffer, UINT16* index);
UINTN _MyStrlen(unsigned char *string);
VOID    TraceDebug ( UINT32 Level, CHAR8 *Format, ...);

extern void IoWrite8(unsigned short bPort, unsigned char byte);
extern void IoWrite32(unsigned short wPort, unsigned long ddByte);
extern unsigned char IoRead8(unsigned short wPort);
extern unsigned long IoRead32(unsigned short wPort);

#define bport IoWrite8
#define	dport IoWrite32

#define EFI_PCI_ADDRESS(bus, dev, func, reg) \
    ((UINT64) ((((UINTN) bus) << 16) + (((UINTN) dev) << 11) + (((UINTN) func) << 8) + ((UINTN) reg)))

#define MmioAddress(BaseAddr, Register) \
    ( (UINTN)BaseAddr + (UINTN)(Register) )

// 8-bit
#define Mmio8Ptr(BaseAddr, Register) \
    ( (volatile UINT8 *)MmioAddress(BaseAddr, Register) )

#define Mmio8(BaseAddr, Register) \
    *Mmio8Ptr(BaseAddr, Register)

#define MmioRead8(Addr) \
    Mmio8(Addr, 0)

#define MmioWrite8(Addr, Value) \
    (Mmio8(Addr, 0) = (UINT8)Value)

#define MmioRW8(Addr, set, reset) \
    (Mmio8(Addr, 0) = ((Mmio8(Addr, 0) & (UINT8)~(reset)) | (UINT8)set))

// 16-bit
#define Mmio16Ptr(BaseAddr, Register) \
    ( (volatile UINT16 *)MmioAddress(BaseAddr, Register) )

#define Mmio16(BaseAddr, Register) \
    *Mmio16Ptr(BaseAddr, Register)

#define MmioRead16(Addr) \
    Mmio16(Addr, 0)

#define MmioWrite16(Addr, Value) \
    (Mmio16(Addr, 0) = (UINT16)Value)

#define MmioRW16(Addr, set, reset) \
    (Mmio16(Addr, 0) = ((Mmio16(Addr, 0) & (UINT16)~(reset)) | (UINT16)set))

// 32-bit
#define Mmio32Ptr(BaseAddr, Register) \
    ( (volatile UINT32 *)MmioAddress(BaseAddr, Register) )

#define Mmio32(BaseAddr, Register) \
    *Mmio32Ptr(BaseAddr, Register)

#define MmioRead32(Addr) \
    Mmio32(Addr, 0)

#define MmioWrite32(Addr, Value) \
    (Mmio32(Addr, 0) = (UINT32)Value)

#define MmioRW32(Addr, set, reset) \
    (Mmio32(Addr, 0) = ((Mmio32(Addr, 0) & (UINT32)~(reset)) | (UINT32)set))

#if 0
#ifdef va_list
    #undef va_list
    typedef CHAR8 *VA_LIST;
    #define va_list VA_LIST
#endif
#ifdef va_start
   	#undef va_start
    #define va_start(ap, v)  ( ap = (va_list)&(v) + ( (sizeof (v) + sizeof (UINTN) - 1) & ~(sizeof (UINTN) - 1) ) )
#endif

#ifdef va_arg
    #undef va_arg
	#define va_arg(ap, t)    ( *(t *) ((ap += ( (sizeof (t) + sizeof (UINTN) - 1) & ~(sizeof (UINTN) - 1) )) - ( (sizeof (t) + sizeof (UINTN) - 1) & ~(sizeof (UINTN) - 1) )) )
#endif
#ifdef va_end
    #undef va_end
	#define va_end(ap)      ( ap = (va_list)0 )
#endif
#endif

#ifdef __GNUC__
#undef va_start
#undef   va_end
#undef   va_arg
#define va_start(v,l)   __builtin_va_start(v,l)
#define va_end(v)   __builtin_va_end(v)
#define va_arg(v,l)   __builtin_va_arg(v,l)
typedef __builtin_va_list va_list;
#else
#include <stdarg.h>
#endif

#if	1
UINTN _MyStrlen(unsigned char *string) {
  unsigned char *pString;
	UINTN length=0;
  pString = string;
	while(*pString++) length++;
	return length;
}
#endif

VOID InitSerialOut(VOID)
{
	UINT32	Address;
	// Enable SB RCBA
	Address = 0x80000000|(0<<16)|(0x1F<<11)|(0<<8)|0xF0;
	IoWrite32(0xCF8, Address);
	IoWrite32(0xCFC, (SB_RCBA+1));
}

VOID
TraceDebug (
         UINT32 Level,
         CHAR8 *Format, 
  	   ...
  )
{
//  CHAR8 temp[16];
  CHAR8 outputTemp[512];
//  CHAR8	*pStringTemp;
//  va_list  ArgList;
//  UINT32 Radix;
//  UINT64 U64DataRadix;
//  UINT8	isU64Data, nDigits;
//  UINT8 isGUID;
  UINT16	outputIndex;
  UINT32 nCount;
  InitSerialOut();
  //ArgList = 
//  va_start (ArgList, Format);

//  SendStringPort ("\t\tPCH Log: ");
  outputIndex = 0;
  for(outputIndex=0;outputIndex<512;outputIndex++)
	 outputTemp[outputIndex] = 0;

  outputIndex = 0;
  nCount = 0;
  
SendStringPort(Format);
//SendBytePort (*Format);

#if 0

  while ( nCount++ < 1024 ) {

    if ( *Format == 0 ) {
      break;
    }

    if ( *Format == '%' ) {
      Radix = 0;

      if ( *(Format + 1) == 'r' ) {

	if( (U64DataRadix=va_arg (ArgList, UINT32)) == 0 )
	        SendStringToBufferPort ((unsigned char*)"EFI_SUCCESS", 11, outputTemp, &outputIndex);
	else {
		Radix = 16;
		SendStringToBufferPort ((unsigned char*)"Status code:", 12, outputTemp, &outputIndex);
		ItoA ((UINT32)(U64DataRadix), Radix, temp);
	        SendStringToBufferPort (temp, 4, outputTemp, &outputIndex);		
	}
        Format += 2;
        continue;
      }

      if ( *(Format + 1) == 's' || *(Format + 1) == 'S' ) {
        
		    pStringTemp = va_arg (ArgList, CHAR8*);
        if (!pStringTemp)
            pStringTemp = (CHAR8*)"<NULL>";
        
        SendStringToBufferPort ( pStringTemp, (UINT16)_MyStrlen(pStringTemp), outputTemp, &outputIndex  );
        /*
        //ItoA ((UINT32)*(CHAR8**)pStringTemp, 16, temp);
        if(pStringTemp != NULL && pStringTemp != 0 ) {
          ItoA((UINT16)_MyStrlen(pStringTemp), 10, temp);
          SendStringPort (temp);
          SendStringPort ((unsigned char*)"--");
        }
        */
        //SendStringPort ( *(CHAR8**)pStringTemp );
        //SendStringPort ( pStringTemp );
        Format += 2;
        continue;
      }

      nDigits = 0;
      if ( *(Format + 1) == '0' && *(Format + 2) == '0') {
             Format += 2;	//By pass digit '0'.
      } else if( *(Format + 1) == '0' )
      		Format += 1;
      
      if ( *(Format + 1) >= '1' && *(Format + 1) <= '9' ) {
	nDigits =  *(Format + 1) - '0';
        Format += 1;	//By pass digits

        if ( *(Format + 1) >= '1' && *(Format + 1) <= '9' ) {
  	      
   	  nDigits = nDigits*10 + *(Format + 1) - '0';
          Format += 1;	//By pass digits
        }
      }
      
      if ( *(Format + 1) == 'd' || *(Format + 1) == 'D' ) {
        Radix = 10;
      }

      isU64Data = 0;
      if ( *(Format + 1) == 'p' || *(Format + 1) == 'P' || *(Format + 1) == 'l' || *(Format + 1) == 'L' ) {
        Format += 1;	//By pass l,L
	isU64Data = 1;
      }

      if ( *(Format + 1) == 'x' || *(Format + 1) == 'X' ) {
        Radix = 16;
	//SendStringPort ("0x");
	SendStringToBufferPort((unsigned char*)":", 2, outputTemp, &outputIndex );
      }
      isGUID = 0;
      if ( *(Format + 1) == 'g' || *(Format + 1) == 'G' ) {
         Radix = 16;
         isGUID = 1;
      }
      if ( Radix && (isGUID ==0)) {
	if( !isU64Data ){
		U64DataRadix = va_arg (ArgList, UINT32); 
	        ItoA ((UINT32)U64DataRadix, Radix, temp);
	        //SendStringPort (temp);
		SendStringToBufferPort(temp, sizeof(UINT32), outputTemp, &outputIndex );
	}
	else {
		U64DataRadix = va_arg (ArgList, UINT64);
		ItoA ((UINT32)(U64DataRadix>>32), Radix, temp);
	        SendStringPort (temp);
		SendBytePort ('-');
		ItoA ((UINT32)(U64DataRadix), Radix, temp);
	        SendStringPort (temp);
	}
        Format += 2;
        continue;
      } 
      /*else if( Radix && (isGUID == 1)) {
      	  EFI_GUID *lGuid;
	      U64DataRadix = va_arg (ArgList, UINT32);
	      lGuid = (EFI_GUID*)U64DataRadix;
	      
      	      ItoA (lGuid->Data1, Radix, temp);
      	      SendStringPort (temp);
              SendBytePort ('-');
      	      ItoA ((UINT16)(lGuid->Data2), Radix, temp);
      	      SendStringPort (temp);
       	      SendBytePort ('-');
      	      ItoA ((UINT16)(lGuid->Data3), Radix, temp);
      	      SendStringPort (temp);
		      Format += 2;
        continue;
      }
      */
    }
    SendByteToBufferPort (*Format, outputTemp, &outputIndex);

    //if ( *(Format) == 0x0a || *(Format) == '\n' || outputIndex>510 ) {
    if(outputIndex > 510 ) {
      SendByteToBufferPort ('\n' , outputTemp, &outputIndex);
      SendStringPort(outputTemp);
      for(outputIndex=0;outputIndex<512;outputIndex++)
	       outputTemp[outputIndex] = 0;
      outputIndex = 0;
    }
   SendByteToBufferPort (*Format, outputTemp, &outputIndex); 
    // if(outputIndex > 510 ) {
    //  for(outputIndex=0;outputIndex<512;outputIndex++)
    //     outputTemp[outputIndex] = 0;
    //  outputIndex = 0;      
    // }
    SendBytePort (*Format);
    Format++;
  }
  //va_end (ArgList);
  //if( outputIndex != 0 ) {
  //    SendStringPort(outputTemp);
  //}
#endif   

}

VOID
ItoA (
         UINT32 Value,
         UINT32 Radix,
         CHAR8* pstr
  )
{
  CHAR8* tsptr;
  CHAR8* rsptr;
  CHAR8  ch1;
  CHAR8  ch2;
  UINT32 Reminder;
  tsptr = pstr;
  rsptr = pstr;
//Create String
  do {
    Reminder = Value % Radix;
    Value = Value / Radix;
    if ( Reminder < 0xa ) {
      *tsptr = (CHAR8)Reminder + '0';
    } else {
      *tsptr = (CHAR8)Reminder - 0xa + 'a';
    }
    tsptr++;
  } while ( Value );
//Reverse String
  *tsptr = 0;
  tsptr--;
  while ( tsptr > rsptr ) {
    ch1 = *tsptr;
    ch2 = *rsptr;
    *rsptr = ch1;
    *tsptr = ch2;
    tsptr--;
    rsptr++;
  }
}


VOID
SendStringPort (
         CHAR8* pstr
  )
{
	UINT32  backup_data1=0, backup_data2=0, backup_data3=0, backup_data4=0;	//bakup register
	UINT8	backup_data5[0x40];						//backup data buffer
	CHAR8* pStrBackup = pstr;
/*
  while ( *pstr!=0 ) {
    SendBytePort (*pstr);
    pstr++;
  }

*/


	Intel_Spi_Backup(&backup_data1, &backup_data2, &backup_data3, &backup_data4, backup_data5);

	EM100_Transfer(pStrBackup);         								//Emulator is EM100

	Intel_Spi_Restore(backup_data1, backup_data2, backup_data3, backup_data4, backup_data5);

}

VOID
SendBytePort (
         UINT8 Data
  )
{

	UINT8	DataBuffer[4];
	UINT32  backup_data1=0, backup_data2=0, backup_data3=0, backup_data4=0;	//bakup register
	UINT8	backup_data5[0x40];						//backup data buffer
	DataBuffer[0] = Data;
	DataBuffer[1] = 0;
	DataBuffer[2] = 0;
	DataBuffer[3] = 0;

	Intel_Spi_Backup(&backup_data1, &backup_data2, &backup_data3, &backup_data4, backup_data5);

	EM100_Transfer(DataBuffer);         								//Emulator is EM100

	Intel_Spi_Restore(backup_data1, backup_data2, backup_data3, backup_data4, backup_data5);

/*
{
  INT8   Count;
  UINT8 Status;

  Count = 80;
  do {
    Status = IoRead8 (COM_BASE_ADDRESS + 0x05);
    if ( Status == 0xff ) {
      break;
    }
    // Loop  port is ready
  } while ( (Status & 0x20) == 0 && (--Count) != 0 );
  bport (COM_BASE_ADDRESS + 0x00, Data);
}
*/
}

VOID SendByteToBufferPort (UINT8 Data, CHAR8* buffer, UINT16* index) {
	if(*index < 128)
    buffer[*index] = Data;
	//*index = *index + 1;
}

VOID SendStringToBufferPort (CHAR8* pstr, UINT16 nLength, CHAR8* buffer, UINT16* index) {
	UINTN i;
	for(i=0;i<nLength;i++)
		buffer[*index+i] = pstr[i];
	*index += nLength;
}


//<AMI_PHDR_START>
//============================================================================
// Procedure: WaitForCycleDone
//
// Description:	
//
// Input:
//     
//
// Output: 
//
//============================================================================
//<AMI_PHDR_END>

EFI_STATUS WaitForCycleDone()
{
	volatile  UINT16   TempSpiStatus;
    	volatile UINT8 *a = (volatile UINT8*)(SPI_ACCESS_BASE + SC_INTEL_REG_SPI_SSFSTS);

    // Wait until "Cycle Done Status" bit is 1
    do
    {
        TempSpiStatus = *a;
    }
    while ((TempSpiStatus & SC_INTEL_REG_SPI_SSFSTS_SCDS) != SC_INTEL_REG_SPI_SSFSTS_SCDS);
	//while (RetryCounter--) if((Mmio8(SB_RCBA+SPI_BASE_ADDRESS, SC_INTEL_REG_SPI_SSFSTS)&BIT2) != 0) break;
//	while((Mmio8(SB_RCBA+SPI_BASE_ADDRESS, SC_INTEL_REG_SPI_SSFSTS)&BIT0)!=0);
// check for errors
    TempSpiStatus = *a;

#ifndef	NM10
    if ((TempSpiStatus & SC_INTEL_REG_SPI_SSFSTS_FCERR) == SC_INTEL_REG_SPI_SSFSTS_FCERR)
        return EFI_DEVICE_ERROR;
#endif
    // Clear the "Cycle Done Status" and "Flash Cycle Error" bits
#ifndef	NM10
    *a |= (SC_INTEL_REG_SPI_SSFSTS_SCDS | SC_INTEL_REG_SPI_SSFSTS_FCERR);
#else
    *a |= (SC_INTEL_REG_SPI_SSFSTS_SCDS);
#endif
    return EFI_SUCCESS;
}

//<AMI_PHDR_START>
//============================================================================
// Procedure: Intel_Spi_No_addr_Wr
//
// Description:	
//
// Input:
//     
//
// Output: 
//
//============================================================================
//<AMI_PHDR_END>
EFI_STATUS Intel_Spi_No_addr_Wr (
		UINT16	Data_Byte_Count,
		UINT8	Byte1,
		UINT8	Byte2,
		UINT8	Byte3,
		UINT8	Byte4
)
{
	UINT8	i=0;
	UINT16	ControlData;
					
 	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_OPMENU) = Byte1;
	// Address Required, Read cycle type	
	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_OPTYPE) = 0x01;

	if(Data_Byte_Count>0x3F)Data_Byte_Count=0x3F;

	ControlData = Data_Byte_Count;
	ControlData <<= 8;
	ControlData |= (1 << 14);
	ControlData += BIT1;

	//clear all flash data buffer.
	for(i=0;i<0x40;i++)Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FDATA0+i)=0; 

	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FDATA0) = Byte2;
	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FDATA0+1) = Byte3;
	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FDATA0+2) = Byte4;

	Mmio16(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_SSFCTL) = ControlData;
	WaitForCycleDone();

	return EFI_SUCCESS;
}

//<AMI_PHDR_START>
//============================================================================
// Procedure: Intel_Spi_addr_Rd
//
// Description:	
//
// Input:
//     
//
// Output: 
//
//============================================================================
//<AMI_PHDR_END>
EFI_STATUS Intel_Spi_addr_Rd(
		UINT16	Data_Byte_Count,
		UINT8	Byte1,
		UINT8	Byte2,
		UINT8	Byte3,
		UINT8	Byte4,
	 	UINT32 	*Flash_Data0 
)
{
	UINT16	ControlData;

	// EM100 Dedicated instruction opcode
	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_OPMENU) = Byte1;
	// Address Required, Read cycle type	
	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_OPTYPE) = 0x02;

	ControlData = Data_Byte_Count;
	ControlData <<= 8;
	ControlData |= (1 << 14);
	ControlData += BIT1;

	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FADDR) = Byte4;
	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FADDR+1) = Byte3;
	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FADDR+2) = Byte2;

	Mmio16(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_SSFCTL) = ControlData;
	WaitForCycleDone();

	*Flash_Data0 = Mmio32(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FDATA0);

	return EFI_SUCCESS;
}

//<AMI_PHDR_START>
//============================================================================
// Procedure: Intel_Spi_addr_Wr
//
// Description:	
//
// Input:
//     
//
// Output: 
//
//============================================================================
//<AMI_PHDR_END>

EFI_STATUS Intel_Spi_addr_Wr(
		UINT16	Data_Byte_Count,
		UINT8	Byte1,
		UINT8	Byte2,
		UINT8	Byte3,
		UINT8	Byte4,      //Data 0 
    	 	UINT8 	*Flash_Data 
)
{
	UINT16	ControlData;
	int i;
	// EM100 Dedicated instruction opcode
	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_OPMENU) = Byte1;
	// Address Required, Read cycle type	
	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_OPTYPE) = 0x03;

   	if(Data_Byte_Count>0x3F)Data_Byte_Count=0x3F;

	ControlData = Data_Byte_Count;
	ControlData <<= 8;
	ControlData |= (1 << 14);
	ControlData += BIT1;

	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FADDR) = Byte4;
	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FADDR+1) = Byte3;
	Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FADDR+2) = Byte2;

	//clear all flash data buffer.
	for(i=0;i<0x40;i++)Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FDATA0+i)=0; 
 
 	//Fill all flash data to buffer.
	for(i=0;i<Data_Byte_Count;i++)Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FDATA0+i)=Flash_Data[i];

	Mmio16(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_SSFCTL) = ControlData;

	WaitForCycleDone();

	return EFI_SUCCESS;

}

//<AMI_PHDR_START>
//============================================================================
// Procedure: Intel_Spi_Backup
//
// Description:	
//
// Input:
//     
//
// Output: 
//
//============================================================================
//<AMI_PHDR_END>
EFI_STATUS Intel_Spi_Backup(
    	 	UINT32 	*OpMenuBackup,
    	 	UINT32 	*OpTypeBackup,
		UINT32	*ControlBackup,
    	 	UINT32 	*dAddressBackup,
    	 	UINT8 	*DataBackup
)
{
	UINT8   BIOS_CNTL_Data, i = 0;
//Backup SPI Registers
	*OpMenuBackup = Mmio32(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_OPMENU);
	*OpTypeBackup = Mmio32(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_PREOP);
	*dAddressBackup = Mmio32(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FADDR);
        for(i=0;i<0x40;i++) {
		      DataBackup[i] = Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FDATA0+i);
	}
	*ControlBackup = Mmio32(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_SSFSTS);		//Backup SSFC(Control) & SSFS(Status) register
//Set Flash Device Wirte Enable , set BIOSWE bit and clear SMM_BWP bit
	IoWrite32(0xCF8, ICH_LPC_PCI_CFG_ADDRESS | ICH_REG_LPC_BIOS_CNTL);
	BIOS_CNTL_Data=IoRead8(0xCFC); 
    	BIOS_CNTL_Data |= BIT00;
    	BIOS_CNTL_Data &= ~BIT05;	       
        IoWrite8(0xCFC, (UINT8)BIOS_CNTL_Data);

	return EFI_SUCCESS;
}

//<AMI_PHDR_START>
//============================================================================
// Procedure: Intel_Spi_Restore
//
// Description:	
//
// Input:
//     
//
// Output: 
//
//============================================================================
//<AMI_PHDR_END>
EFI_STATUS Intel_Spi_Restore(
    	 	UINT32 	OpMenuBackup,
    	 	UINT32 	OpTypeBackup,
		UINT32	ControlBackup,
    	 	UINT32 	dAddressBackup,
    	 	UINT8 	*DataBackup
)
{
	UINT32  ICH_BIOS_RW_Address;
	UINT8   ICH_BIOS_RW, i = 0;
//Restore SB BIOS Write Enable bit
	ICH_BIOS_RW_Address = 0x80000000|(0<<16)|(0x1F<<11)|(0<<8)|0xDC;
	IoWrite32(0xCF8, ICH_BIOS_RW_Address);
	ICH_BIOS_RW=IoRead8(0xCFC);        
//ooo    IoWrite8(0xCFC,ICH_BIOS_RW&0xFE);


//Restore SPI Controller Registers Used!	
	Mmio32(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_SSFSTS) = ControlBackup;		//Restore SSFC & SSFS register
        for(i=0;i<0x40;i++) {
		Mmio8(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FDATA0+i) = DataBackup[i];
	}	
	Mmio32(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_FADDR) = dAddressBackup;
	Mmio32(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_OPMENU) = OpMenuBackup; 
	Mmio32(SPI_ACCESS_BASE, SC_INTEL_REG_SPI_PREOP) = OpTypeBackup;

	return EFI_SUCCESS;
}

//<AMI_PHDR_START>
//============================================================================
// Procedure: EM100_Transfer
//
// Description:	
//
// Input:
//     
//
// Output: 
//
//============================================================================
//<AMI_PHDR_END>

#define BULK_TRANSFER_SIZE 0x1F
EFI_STATUS EM100_Transfer(UINT8 *Data)
{						
	UINT8	Header[] = {0x40, 0x44, 0x36, 0x47, 0x05, 0x00};		// Packet Header(Start Key DWORD)
	UINT8	Header_counter = 0;
	UINTN	Length = 0,TimeOut = 0;
	UINT32	data_byte = 0;
	UINT8	flash_data[0x40];
	UINT16	data_count=0,i,buffer_data_count=0;

	// Detect string length , if no string will skip this service.	
//	if(!(Length=Strlen(Data))) return EFI_SUCCESS;
	Length=_MyStrlen(Data);
  if( Length == 0 )
    return EFI_SUCCESS;
  
	// Check Emulator ready , EM100 API pressed start button to Enable , if Disable will skip this service.

	Intel_Spi_addr_Rd(0x00, 0x11, 0x00, 0xB3, 0x00, &data_byte);			//Read Register3 - EM100 identification	

	data_byte = data_byte & 0xFF;					
	if (!(data_byte == 0xAA))  return EFI_SUCCESS;
			
	data_count = 0;
	
	do
	{		
		// Check Upload FIFO is Empty
		TimeOut = 0;
		do { 

			Intel_Spi_addr_Rd(0x00, 0x11, 0x00, 0xB0, 0x00, &data_byte);	//Read Register0 - Main register

			if ( data_byte & BIT5 )
			break;
			IoWrite8(0xE1, 0xFF);
			IoWrite8(0xE1, 0xFF);
		} while( TimeOut++ < 0x100 );
    
    Intel_Spi_addr_Rd(0x00, 0x11, 0x00, 0xB8, 0x00, &data_byte);
//    Intel_Spi_addr_Rd(0x00, 0x11, 0x00, 0xB0, 0x00, &data_byte);
		// Enter EM100 Communication protocol Method 1 : Mixed data format with Start Key DWORD
		// Packet Header(Byte0 ~Byte5) + Data(Byte6 ~ByteN(max:263))
											
		if(Length > 255) Length = 255;

		buffer_data_count = (UINT16)(Length-data_count);
							
		// Send Packet Header
		if(buffer_data_count >= BULK_TRANSFER_SIZE)
		  Header[5] = BULK_TRANSFER_SIZE+1;					//+1 to correct Data length for EM100 protocol format.
		else
		  Header[5] =(UINT8)buffer_data_count+1;			//+1 to correct Data length for EM100 protocol format.

		Header_counter=sizeof(Header)/ sizeof(Header[0]);

		Intel_Spi_addr_Wr((UINT16)(Header_counter-1) , 0x11, 0x22, 0xC0, Header[0], &Header[1]);		//Write upload FIFO   FLA = 22C000+Data[0]   ;22 is Dont care byte for debug identify


//    Intel_Spi_addr_Rd(0x00, 0x11, 0x00, 0xB0, 0x00, &data_byte);
		// Send Data 
		for(i=0;i<sizeof(flash_data);i++) flash_data[i]=Data[i+data_count]; 


		if((Length-data_count)>=BULK_TRANSFER_SIZE)							
			Intel_Spi_addr_Wr(BULK_TRANSFER_SIZE-1, 0x11, 0x33, 0xC0, flash_data[0], &flash_data[1]);				//Write upload FIFO  FLA = 33C000+Data[0]    ;33 is Dont care byte for debug identify
		else
			Intel_Spi_addr_Wr((UINT16)(buffer_data_count-1) , 0x11, 0x33, 0xC0, flash_data[0], &flash_data[1]);	//Write upload FIFO  FLA = 33C000+Data[0]    ;33 is Dont care byte for debug identify		  		


		data_count = data_count + BULK_TRANSFER_SIZE;

	}while((UINT16)data_count<(UINT16)Length);

	return EFI_SUCCESS;
}


