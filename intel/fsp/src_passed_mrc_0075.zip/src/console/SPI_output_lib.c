#include <arch/io.h>
#include <console/console.h>

void IoWrite8(unsigned short wPort, unsigned char byte);
void IoWrite32(unsigned short wPort, unsigned long ddByte);
unsigned char IoRead8(unsigned short wPort);
unsigned long IoRead32(unsigned short wPort);

void IoWrite8(unsigned short wPort, unsigned char byte) 
{
	outb(byte, wPort);
}

void IoWrite32(unsigned short wPort, unsigned long ddByte)
{
	outl(ddByte, wPort);
}

unsigned char IoRead8(unsigned short wPort)
{
	return inb(wPort);
}
unsigned long IoRead32(unsigned short wPort)
{
	return inl(wPort);
}

